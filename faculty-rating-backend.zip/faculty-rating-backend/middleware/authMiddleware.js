const jwt = require('jsonwebtoken');

const authenticateToken = (req, res, next) => {
    // 1. Token nikalo
    const token = req.header('Authorization');

    if (!token) {
        return res.status(401).json({ message: "Access Denied: No Token Provided!" });
    }

    try {
        // 2. Verify karo
        const JWT_SECRET = process.env.JWT_SECRET || "my_super_secret_key_123";
        
        const decoded = jwt.verify(token, JWT_SECRET);

        // 3. User data request me save karo
        req.user = decoded; 
        
        next(); // Aage badho (Controller ke paas jao)

    } catch (err) {
        res.status(403).json({ message: "Invalid Token" });
    }
};

// IMPORTANT: Curly braces { } me export karein
module.exports = { authenticateToken };