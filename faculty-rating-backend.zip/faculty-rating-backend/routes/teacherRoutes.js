const express = require('express');
const router = express.Router();
const teacherController = require('../controllers/teacherController');

// 👇 CHANGE: Curly braces { } lagayein aur naam sahi karein
const { authenticateToken } = require('../middleware/authMiddleware'); 

// ==================================================
// TEACHER ROUTES
// ==================================================

// 1. Profile Management
// 'authenticateToken' use karein (jo ab ek function hai)
router.get('/profile', authenticateToken, teacherController.getProfile);
router.put('/profile', authenticateToken, teacherController.updateProfile);

// 2. Feedbacks
// Teacher sirf apne feedbacks dekhega
router.get('/my-feedbacks', authenticateToken, teacherController.getMyFeedbacks);

// Note: 'getAllFeedbacks' usually Admin ke liye hota hai, teacher ke liye nahi. 
// Agar teacher ko sabka dekhna allow nahi hai to isse hata sakte hain.
// router.get('/all-feedbacks', authenticateToken, teacherController.getAllFeedbacks); 

// 3. Interactions (Like/Reply)
router.post('/feedback/like', authenticateToken, teacherController.toggleLike);
router.post('/feedback/reply', authenticateToken, teacherController.postReply);

module.exports = router;