const express = require('express');
const router = express.Router();
const adminController = require('../controllers/adminController');

// 👇 FIX: Curly braces { } lagayein aur naam sahi karein
const { authenticateToken } = require('../middleware/authMiddleware');

// ==================================================
// ADMIN ROUTES
// ==================================================

// 1. Feedback Management
// 'authMiddleware' ki jagah 'authenticateToken' use karein
router.get('/feedbacks', authenticateToken, adminController.getAllFeedbacks);
router.post('/delete-feedback', authenticateToken, adminController.deleteFeedback);

// 2. Student Management
router.post('/block-student', authenticateToken, adminController.blockStudent);
router.post('/send-warning', authenticateToken, adminController.sendWarning);

// 3. Teacher Management
router.get('/teachers', authenticateToken, adminController.getAllTeachers);
router.post('/add-teacher', authenticateToken, adminController.addTeacher);
router.post('/delete-teacher', authenticateToken, adminController.deleteTeacher);

module.exports = router;