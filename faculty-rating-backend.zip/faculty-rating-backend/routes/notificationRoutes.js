const express = require('express');
const router = express.Router();
const notificationController = require('../controllers/notificationController');
// ⚠️ Future mein yahan Admin Middleware (authMiddleware.isAdmin) lagega

// ===================================
// 1. NOTIFICATION ROUTE
// ===================================

// Route to send a pre-defined warning email to a user
// Requires: { email, userName, warningType ('VULGAR_LANGUAGE' or 'SPAMMING'), commentId (optional) }
router.post('/sendWarning', notificationController.sendWarning);

module.exports = router;