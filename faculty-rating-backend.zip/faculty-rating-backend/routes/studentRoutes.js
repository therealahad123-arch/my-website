const express = require('express');
const router = express.Router();

// NOTE: Ensure your authMiddleware exports a function named 'authenticateToken'
const { authenticateToken } = require('../middleware/authMiddleware'); 
const studentController = require('../controllers/studentController');

// ==================================================
// STUDENT ROUTES
// ==================================================

// 1. Dropdown ke liye Teachers ki list (Student Dashboard par)
// URL: /api/student/teachers
router.get('/teachers', authenticateToken, studentController.getAllTeachers);

// 2. Student Dashboard Data (Profile/Stats agar chahiye ho)
// URL: /api/student/dashboard
router.get('/dashboard', authenticateToken, studentController.getStudentDashboard);

// 3. 🛑 NEW WARNING ROUTE: Student ke liye unviewed warnings fetch karna.
// URL: /api/student/warnings
router.get('/warnings', authenticateToken, studentController.getUnviewedWarnings);

// 4. 🛑 NEW WARNING ROUTE: Student ki warnings ko 'dekh liya gaya' (Viewed) mark karna.
// URL: /api/student/warnings/viewed
router.post('/warnings/viewed', authenticateToken, studentController.markWarningAsViewed);

// ⚠️ IMPORTANT: Aapko apne 'studentController.js' mein ab yeh 4 functions banane honge.

module.exports = router;