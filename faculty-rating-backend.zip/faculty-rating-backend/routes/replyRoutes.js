const express = require("express");
const router = express.Router();
const replyController = require("../controllers/replyController");

router.post("/add", replyController.addReply);
router.get("/teacher/:teacher_name", replyController.getReplies);

module.exports = router;
