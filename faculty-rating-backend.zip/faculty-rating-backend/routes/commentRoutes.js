const express = require("express");
const router = express.Router();
const commentController = require("../controllers/commentController");

// POST a new comment
router.post("/", commentController.postComment); 

// GET /api/comments
router.get("/", commentController.getAllComments);

module.exports = router;
