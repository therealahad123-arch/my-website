const express = require("express");
const router = express.Router();
const feedbackController = require("../controllers/feedbackController");

// IMPORTANT: Middleware import karna zaroori hai
// Ye check karega ki user logged in hai ya nahi
const { authenticateToken } = require("../middleware/authMiddleware");

// ===========================================
// 1. Submit Feedback (Student Only)
// ===========================================
// 'authenticateToken' lagaya taaki hum req.user.id nikal sakein
router.post("/add", authenticateToken, feedbackController.submitFeedback);

// ===========================================
// 2. Get Feedbacks for a Teacher
// ===========================================
// URL ab aisa dikhega: /api/feedback/teacher/5 (Naam ki jagah ID)
router.get("/teacher/:teacherId", authenticateToken, feedbackController.getFeedbacksForTeacher);

// ===========================================
// 3. Admin: Get All Feedbacks
// ===========================================
router.get("/all", authenticateToken, feedbackController.getAllFeedbacks);

// ===========================================
// 4. Admin: Delete Feedback
// ===========================================
router.delete("/delete", authenticateToken, feedbackController.deleteFeedback);


// ===========================================
// NEW ROUTES FOR PUBLIC VIEW & REPLIES
// ===========================================

// 5. Get All Public Feedbacks (Student/Teacher view)
router.get("/public-feed", authenticateToken, feedbackController.getPublicFeedbacks);

// 6. Post Reply/Comment on a Feedback
router.post("/reply-to-feedback", authenticateToken, feedbackController.replyToFeedback);

// 7. Get Replies for a specific Feedback ID (Frontend isse call karega)
router.get("/replies/:feedbackId", authenticateToken, feedbackController.getFeedbackReplies);

// 8. Like a Feedback
router.post("/like-feedback", authenticateToken, feedbackController.toggleLike); 


module.exports = router;