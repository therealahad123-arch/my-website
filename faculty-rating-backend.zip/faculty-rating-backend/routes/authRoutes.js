const express = require('express');
const router = express.Router();
const authController = require('../controllers/authController');

// ===================================
// 1. REGISTER ROUTES (OTP Bhejenge)
// ===================================
router.post('/registerStudent', authController.registerStudent);
router.post('/registerTeacher', authController.registerTeacher);
router.post('/registerAdmin', authController.registerAdmin);

// ===================================
// 2. VERIFY OTP ROUTE (Ye Naya Hai) 🔥
// ===================================
// Ye ek hi route Student, Teacher, Admin teeno ka OTP verify karega
// Frontend se apko { email, otp, role } bhejna padega
router.post('/verify-otp', authController.verifyOTP);

// ===================================
// 3. LOGIN ROUTES (Verification Check)
// ===================================
router.post('/loginStudent', authController.loginStudent);
router.post('/loginTeacher', authController.loginTeacher);
router.post('/loginAdmin', authController.loginAdmin);

// ===================================
// 4. ADMIN MODERATION ROUTE (⚠️ Admin Middleware Zaroori Hai)
// ===================================
router.post('/toggleUserStatus', authController.toggleUserStatus);


module.exports = router;