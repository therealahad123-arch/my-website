const db = require("../config/db");

const Reply = {
  addReply: (data, callback) => {
    const sql = `INSERT INTO feedback_replies (feedback_id, reply, replied_at)
                 VALUES (?, ?, NOW())`;
    db.query(sql, [data.feedback_id, data.reply], callback);
  },

  getRepliesByTeacher: (teacher_name, callback) => {
    const sql = `
      SELECT fr.*, f.comment, f.student_name
      FROM feedback_replies fr
      JOIN feedbacks f ON f.id = fr.feedback_id
      WHERE f.teacher_name = ?`;
    db.query(sql, [teacher_name], callback);
  }
};

module.exports = Reply;
