const db = require("../config/db");

const Feedback = {
  create: (data, callback) => {
    const sql = `INSERT INTO feedbacks (student_name, teacher_name, teachingStyle, explanation, behaviour, comment, created_at, blocked, likes, dislikes)
                 VALUES (?, ?, ?, ?, ?, ?, NOW(), 0, 0, 0)`;
    db.query(sql, [
      data.student_name,
      data.teacher_name,
      data.teachingStyle,
      data.explanation,
      data.behaviour,
      data.comment,
    ], callback);
  },

  getAll: (callback) => {
    const sql = `SELECT * FROM feedbacks ORDER BY created_at DESC`;
    db.query(sql, callback);
  }
};

module.exports = Feedback;
