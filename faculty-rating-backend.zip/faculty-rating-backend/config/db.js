// config/db.js
const mysql = require('mysql2');

const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '', // apne mysql password yahan daalo agar hai to
  database: 'faculty_rating_db'
});

db.connect((err) => {
  if (err) {
    console.error('DB Connection Error:', err);
  } else {
    console.log('✅ MySQL Connected');
  }
});

module.exports = db;
