// utils/emailService.js
require('dotenv').config();
const nodemailer = require('nodemailer');

const sendEmail = async (email, subject, htmlContent) => {
    try {
        const transporter = nodemailer.createTransport({
            service: 'gmail',
            auth: {
                // Yahan apna ASLI Email string me likhein
                user: 'the.real.ahad123@gmail.com', 
                
                // Yahan wo 16-digit code bina space ke string me likhein
                pass: 'iifnxjtjryguqlph' 
            }
        });

        const mailOptions = {
            from: 'Wisdom University Admin <admin.wisdom@gmail.com>', // Yahan bhi same email likhein
            to: email,
            subject: subject,
            html: htmlContent
        };

        await transporter.sendMail(mailOptions);
        console.log(`✅ Email sent successfully to ${email}`);
        
    } catch (error) {
        console.log("❌ Authentication Error Details:");
        console.error(error); // Pura error print hoga
    }
};

module.exports = sendEmail;