const db = require('../config/db');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const sendEmail = require('../utils/emailService');

// Ensure JWT_SECRET is defined securely
const JWT_SECRET = process.env.JWT_SECRET || "my_super_secret_key_123";

// Random 6-Digit OTP Generator
const generateOTP = () => Math.floor(100000 + Math.random() * 900000).toString();

// Helper to determine table name from role string
const getTableName = (role) => {
    if (role === 'student') return 'students';
    if (role === 'teacher') return 'teachers';
    if (role === 'admin') return 'admins';
    return null; 
};

// ==========================================
//  1. REGISTER FUNCTIONS 
// ==========================================

// Exports for routes
exports.registerStudent = async (req, res) => { await registerUser(req, res, 'students', 'Student'); };
exports.registerTeacher = async (req, res) => { await registerUser(req, res, 'teachers', 'Teacher'); };

// Admin registration is strictly blocked for external users.
exports.registerAdmin = async (req, res) => {
    return res.status(403).json({ error: "Access Restriction: Registration for this user type is currently disabled due to heightened security protocols." });
};

// *** HELPER FUNCTION: Universal Register Logic ***
async function registerUser(req, res, tableName, roleName) {
    const { name, email, password, qualification } = req.body;

    try {
        // 1. UNIVERSAL EMAIL CHECK: Check all three tables for existing email
        const universalCheckSql = `
            SELECT email FROM students WHERE email = ?
            UNION ALL
            SELECT email FROM teachers WHERE email = ?
            UNION ALL
            SELECT email FROM admins WHERE email = ?
        `;

        db.query(universalCheckSql, [email, email, email], async (err, result) => {
            if (err) {
                console.error("Universal Email Check Error:", err);
                return res.status(500).json({ error: "Database error during email check." });
            }

            if (result.length > 0) {
                // Email found in any table
                return res.status(400).json({ error: "This email is already registered with another role or user. Please use a different email." });
            }

            // 2. Hashing and OTP generation
            const hashed = await bcrypt.hash(password, 10);
            const otp = generateOTP();

            // 3. Database Insert
            let sql, params;
            
            if (tableName === 'teachers') {
                sql = `INSERT INTO teachers (name, email, password, qualification, otp, is_verified, is_active) VALUES (?, ?, ?, ?, ?, 0, 1)`;
                params = [name, email, hashed, qualification || 'Not Specified', otp];
            } else {
                // Ensure is_active=1 is included for students/admins (Admin insert is internal only, but structure is ready)
                sql = `INSERT INTO ${tableName} (name, email, password, otp, is_verified, is_active) VALUES (?, ?, ?, ?, 0, 1)`;
                params = [name, email, hashed, otp];
            }

            db.query(sql, params, async (err, result) => {
                if (err) {
                    console.error("Insert Error:", err);
                    return res.status(500).json({ error: "Database error during registration" });
                }

                // 4. Send Email
                const emailSubject = `Verify Your ${roleName} Account`;
                const emailContent = `
                    <h3>Verification Needed</h3>
                    <p>Hello <strong>${name}</strong>,</p>
                    <p>You have registered as a <strong>${roleName}</strong> at Wisdom University.</p>
                    <br>
                    <p>Your Verification OTP is:</p>
                    <h2 style="color: #2c3e50; background: #f1c40f; padding: 10px; display: inline-block; border-radius: 5px;">${otp}</h2>
                    <p>Please enter this code to activate your account.</p>
                `;

                try {
                    await sendEmail(email, emailSubject, emailContent);
                    res.json({ message: `${roleName} registered successfully! OTP sent to email.` });
                } catch (emailErr) {
                    console.error("Email failed:", emailErr);
                    res.status(500).json({ error: "User registered but failed to send email. Check .env file." });
                }
            });
        });
    } catch (err) {
        console.error("Server catch error:", err);
        res.status(500).json({ error: "Server Error" });
    }
}


// ==========================================
//  2. UNIVERSAL VERIFY OTP 
// ==========================================

exports.verifyOTP = (req, res) => {
    const { email, otp, role } = req.body;

    const tableName = getTableName(role);
    if (!tableName) return res.status(400).json({ error: "Invalid Role specified" });

    const sql = `SELECT * FROM ${tableName} WHERE email = ?`;

    db.query(sql, [email], (err, results) => {
        if (results.length === 0) return res.status(400).json({ error: "User not found" });

        const user = results[0];

        // Match OTP
        if (user.otp === otp) {
            // Verified karo aur OTP null kar do
            const updateSql = `UPDATE ${tableName} SET is_verified = 1, otp = NULL WHERE email = ?`;
            db.query(updateSql, [email], () => {
                res.json({ message: "Verification Successful! You can login now." });
            });
        } else {
            res.status(400).json({ error: "Invalid OTP! Please try again." });
        }
    });
};


// ==========================================
//  3. LOGIN FUNCTIONS (Includes Security Checks)
// ==========================================

// *** HELPER FUNCTION: Login Logic ***
const loginUser = (req, res, tableName, role) => {
    const { email, password } = req.body;
    const sql = `SELECT * FROM ${tableName} WHERE email = ?`;

    db.query(sql, [email], async (err, results) => {
        if (err) {
             console.error("Login DB Error:", err);
             return res.status(500).json({ error: 'Database error during login.' });
        }
        if (results.length === 0) return res.status(401).json({ error: 'Invalid email or user not found in this role.' });

        const user = results[0];

        // 1. VERIFICATION CHECK
        if (user.is_verified === 0) {
            return res.status(403).json({ error: "Account not verified. Please verify OTP first." });
        }
        
        // 2. 🛑 CRITICAL SECURITY CHECK: IS ACTIVE CHECK (Block/Unblock) 🛑
        if (user.is_active === 0) {
            return res.status(403).json({ error: "Access Denied. Your account has been permanently disabled due to policy violation." });
        }
        
        // 3. PASSWORD MATCH
        const match = await bcrypt.compare(password, user.password);

        if (match) {
            const token = jwt.sign(
                { id: user.id, role: role, name: user.name }, 
                JWT_SECRET, 
                { expiresIn: '1d' }
            );

            res.json({ 
                message: `${role} login successful`,
                token: token,
                user: { id: user.id, name: user.name, email: user.email, role: role }
            });
        } else {
            res.status(401).json({ error: 'Invalid password' });
        }
    });
};

// Exports for routes
exports.loginStudent = (req, res) => { loginUser(req, res, 'students', 'student'); };
exports.loginTeacher = (req, res) => { loginUser(req, res, 'teachers', 'teacher'); };
exports.loginAdmin = (req, res) => { loginUser(req, res, 'admins', 'admin'); };


// ==========================================
//  4. MODERATION FUNCTION (Admin Only)
// ==========================================

// ADMIN FUNCTION: Blocks or Unblocks a user by toggling the is_active column.
exports.toggleUserStatus = (req, res) => {
    // ⚠️ Is endpoint par Admin-only middleware lagana bahut zaroori hai.
    
    // status 0 = Block, 1 = Unblock
    const { email, role, status } = req.body; 

    const tableName = getTableName(role);
    
    // Ensure the status value is exactly 0 or 1, and prevent admin modification through this endpoint
    const statusValue = parseInt(status);
    if (!tableName || (role === 'admin') || (statusValue !== 0 && statusValue !== 1)) {
        return res.status(400).json({ error: "Invalid request parameters or unauthorized role for this action." });
    }

    // SQL query to update the is_active column
    const sql = `UPDATE ${tableName} SET is_active = ? WHERE email = ?`;

    db.query(sql, [statusValue, email], (err, result) => {
        if (err) {
            console.error("Database update error:", err);
            return res.status(500).json({ error: "Database error during status update." });
        }

        if (result.affectedRows === 0) {
            return res.status(404).json({ error: `User with email ${email} not found in ${tableName} table.` });
        }

        const action = statusValue === 0 ? 'Blocked' : 'Unblocked';
        res.json({ message: `${role} account for ${email} has been successfully ${action}.` });
    });
};