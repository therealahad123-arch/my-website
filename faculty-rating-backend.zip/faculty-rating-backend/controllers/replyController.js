const Reply = require("../models/reply");

exports.addReply = (req, res) => {
  Reply.addReply(req.body, (err, result) => {
    if (err) return res.status(500).json({ error: "Reply failed" });
    res.status(200).json({ message: "Reply added" });
  });
};

exports.getReplies = (req, res) => {
  const { teacher_name } = req.params;
  Reply.getRepliesByTeacher(teacher_name, (err, rows) => {
    if (err) return res.status(500).json({ error: "Failed to fetch replies" });
    res.status(200).json(rows);
  });
};
