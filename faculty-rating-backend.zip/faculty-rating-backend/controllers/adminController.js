const db = require('../config/db');
const bcrypt = require('bcrypt');
// Change 1: Updated Import (Generic Email Service)
const sendEmail = require('../utils/emailService'); 

// 1. Get All Feedbacks
exports.getAllFeedbacks = (req, res) => {
    const sql = `
        SELECT f.*, s.name as student_name, s.email as student_email, s.is_blocked, t.name as teacher_name 
        FROM feedbacks f
        JOIN students s ON f.student_id = s.id
        JOIN teachers t ON f.teacher_id = t.id
        ORDER BY f.created_at DESC
    `;
    db.query(sql, (err, results) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(results);
    });
};

// 2. Delete Abusive Comment
exports.deleteFeedback = (req, res) => {
    const { id } = req.body;
    const sql = "DELETE FROM feedbacks WHERE id = ?";
    db.query(sql, [id], (err, result) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ message: "Feedback deleted successfully" });
    });
};

// 3. Block Student
exports.blockStudent = (req, res) => {
    const { studentId } = req.body;
    const sql = "UPDATE students SET is_blocked = 1 WHERE id = ?";
    db.query(sql, [studentId], (err, result) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ message: "Student has been blocked" });
    });
};

// 4. Send Warning Notification
exports.sendWarning = (req, res) => {
    const { studentId, message } = req.body;
    const sql = "INSERT INTO notifications (student_id, message) VALUES (?, ?)";
    db.query(sql, [studentId, message], (err, result) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ message: "Warning sent successfully" });
    });
};

// 5. Get All Teachers
exports.getAllTeachers = (req, res) => {
    const sql = "SELECT * FROM teachers";
    db.query(sql, (err, results) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(results);
    });
};

// 6. Add New Teacher (Updated for Email Service & Auto Verify)
exports.addTeacher = async (req, res) => {
    // Security Check: Only Admin can add teachers
    if (req.user.role !== 'admin') {
        return res.status(403).json({ error: "Access Denied" });
    }

    const { name, email, password, qualification, experience } = req.body;
    
    // Password hash karna
    const hashed = await bcrypt.hash(password, 10);

    // Change 2: SQL me 'is_verified' = 1 daal diya (Auto verify)
    const sql = "INSERT INTO teachers (name, email, password, qualification, experience, is_verified) VALUES (?, ?, ?, ?, ?, 1)";
    
    const expValue = experience || 0;

    db.query(sql, [name, email, hashed, qualification, expValue], async (err, result) => {
        if (err) {
            console.error(err);
            return res.status(500).json({ error: "Failed to add teacher (Email might be duplicate)" });
        }

        // Change 3: Naya Email Logic (HTML Content)
        const emailContent = `
            <h3>Welcome to Wisdom University!</h3>
            <p>Hello <strong>${name}</strong>,</p>
            <p>Your Teacher account has been created by the Admin.</p>
            <div style="background: #f4f4f4; padding: 15px; border-radius: 5px; margin: 10px 0;">
                <p style="margin: 5px 0;"><strong>Email:</strong> ${email}</p>
                <p style="margin: 5px 0;"><strong>Password:</strong> ${password}</p>
            </div>
            <p>Please login and change your password immediately.</p>
        `;

        try {
            // Ab generic sendEmail use kar rahe hain (Email, Subject, HTML)
            await sendEmail(email, "Teacher Account Credentials", emailContent);
            res.json({ message: "Teacher added and Credentials sent to email!" });
        } catch (emailError) {
            console.error("Teacher added but Email failed:", emailError);
            res.json({ message: "Teacher added, but failed to send email." });
        }
    });
};

// 7. Delete Teacher
exports.deleteTeacher = (req, res) => {
    const { id } = req.body;
    const sql = "DELETE FROM teachers WHERE id = ?";
    db.query(sql, [id], (err, result) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ message: "Teacher deleted successfully" });
    });
};