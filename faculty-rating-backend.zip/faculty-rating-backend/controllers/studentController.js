const db = require('../config/db'); // आपका MySQL DB कनेक्शन

// ==================================================
// 1. DATA FETCHING (TEACHERS & DASHBOARD)
// ==================================================

// 1a. GET ALL TEACHERS (Dropdown ke liye)
exports.getAllTeachers = (req, res) => {
    // SECURITY/FUNCTIONALITY FIX: Sirf active teachers ko fetch karein
    const sql = `SELECT id, name, qualification, department FROM teachers WHERE is_active = 1`;
    
    db.query(sql, (err, results) => {
        if (err) {
            console.error("Error fetching teachers:", err);
            return res.status(500).json({ error: "Failed to fetch teachers list" });
        }
        res.json(results);
    });
};

// 1b. GET STUDENT DASHBOARD DATA
exports.getStudentDashboard = (req, res) => {
    const studentEmail = req.user.email; // Middleware से मिला Email
    
    // Student की ज़रूरी जानकारी fetch करें
    const sql = `SELECT name, email, is_verified, created_at FROM students WHERE email = ?`; 

    db.query(sql, [studentEmail], (err, result) => {
        if (err) {
            console.error("Error fetching student dashboard data:", err);
            return res.status(500).json({ error: "Failed to load dashboard data." });
        }
        if (result.length === 0) {
            return res.status(404).json({ error: "Student not found." });
        }
        
        // Final response
        res.json({
            message: "Welcome to Student Dashboard",
            student: result[0]
        });
    });
};


// ==================================================
// 2. WARNING MODERATION LOGIC
// ==================================================

// 2a. GET: Student के लिए अनदेखी वार्निंग्स फेच करना
// Route: /api/student/warnings
exports.getUnviewedWarnings = (req, res) => {
    const studentEmail = req.user.email; // Middleware से मिला Email

    const sql = `
        SELECT warning_id, warning_type, warning_date, comment_id
        FROM warnings 
        WHERE user_email = ? AND is_viewed = FALSE
        ORDER BY warning_date DESC
    `;

    db.query(sql, [studentEmail], (err, warnings) => {
        if (err) {
            console.error("Error fetching unviewed warnings:", err);
            return res.status(500).json({ error: "Could not fetch warnings." });
        }
        // वार्निंग्स और उनके IDs वापस भेजें
        // Note: पुराना 'id' कॉलम यहाँ 'warning_id' है
        return res.json({ success: true, warnings: warnings });
    });
};

// 2b. POST: वार्निंग्स को 'देखी गई' (Viewed) मार्क करना
// Route: /api/student/warnings/viewed
exports.markWarningAsViewed = (req, res) => {
    const studentEmail = req.user.email; 
    const { warningIds } = req.body; // Array of warning IDs

    if (!warningIds || warningIds.length === 0) {
        return res.status(400).json({ error: "Missing warning IDs to mark as viewed." });
    }

    // Dynamic placeholders for IN clause
    const placeholders = warningIds.map(() => '?').join(', ');
    
    // IMPORTANT: user_email check से security maintain होती है, ताकि कोई और user की warning mark न कर दे
    const sql = `
        UPDATE warnings 
        SET is_viewed = TRUE 
        WHERE user_email = ? AND warning_id IN (${placeholders})
    `;
    
    // Parameters array: Pehle email, phir IDs
    const params = [studentEmail, ...warningIds];

    db.query(sql, params, (err, result) => {
        if (err) {
            console.error("Error marking warnings as viewed:", err);
            return res.status(500).json({ error: "Could not update warning status." });
        }
        return res.json({ success: true, message: `${result.affectedRows} warnings marked as viewed.` });
    });
};