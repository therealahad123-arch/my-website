const sendEmail = require('../utils/emailService');
const db = require('../config/db'); // Ensure DB connection is imported

// ===========================================
// 1. PRE-DEFINED WARNING TEMPLATES (English - FINALIZED)
// ===========================================

const WARNINGS = {
    VULGAR_LANGUAGE: {
        subject: "FINAL WARNING: Severe Policy Violation - Abusive Content",
        body: (name, commentId) => `
            <div style="font-family: Arial, sans-serif; border: 1px solid #E0E0E0; padding: 20px; border-radius: 8px;">
                <h3 style="color: #CC0000; border-bottom: 2px solid #EEE; padding-bottom: 10px;">Official Policy Violation Notice</h3>
                <p>Dear ${name},</p>
                
                <p>This is a formal and final warning regarding your recent feedback submission (Reference ID: <b>${commentId}</b>). The content contained abusive language, which is a **direct violation of the Wisdom University Community Guidelines**.</p>
                
                <p style="background: #FEE; padding: 15px; border-left: 5px solid #CC0000; color: #900; font-weight: bold; font-size: 16px;">
                    🛑 IMPORTANT ACTION REQUIRED: If you are caught violating the community guidelines again, your account will be permanently blocked from accessing the portal.
                </p>
                
                <p>Please review and adhere to our guidelines strictly. No further warnings will be issued for this type of offense.</p>
                
                <p style="font-size: 12px; color: #777; margin-top: 20px;">Wisdom University Administration</p>
            </div>
        `,
        level: 'SEVERE'
    },
    SPAMMING: {
        subject: "Official Warning: Content Quality and Repetitive Submissions",
        body: (name, commentId) => `
            <div style="font-family: Arial, sans-serif; border: 1px solid #E0E0E0; padding: 20px; border-radius: 8px;">
                <h3 style="color: #FF8C00; border-bottom: 2px solid #EEE; padding-bottom: 10px;">Content Quality Warning</h3>
                <p>Dear ${name},</p>
                
                <p>Your recent submission(s) (Reference ID: <b>${commentId}</b>) have been flagged as repetitive, irrelevant, or low-quality content (Spamming).</p>
                
                <p style="background: #FFF8E1; padding: 12px; border-left: 5px solid #FF8C00; color: #704; font-weight: bold;">
                    Please ensure that all future submissions are unique, constructive, and directly relevant to the faculty or course being reviewed.
                </p>
                
                <p>Continued submission of spam content will lead to account restrictions.</p>
                
                <p style="font-size: 12px; color: #777; margin-top: 20px;">Wisdom University Administration</p>
            </div>
        `,
        level: 'MILD'
    }
};

// ===========================================
// 2. CONTROLLER FUNCTION: Send Warning Email & Log (UPDATED)
// ===========================================

exports.sendWarning = async (req, res) => {
    // Admin Front-end se yeh data aayega
    const { email, userName, role, warningType, commentId } = req.body; 

    // Safety check for required fields
    if (!email || !userName || !role || !warningType) {
        return res.status(400).json({ error: "Missing required fields (email, userName, role, warningType)." });
    }

    const warning = WARNINGS[warningType];
    
    if (!warning) {
        return res.status(400).json({ error: "Invalid warning type specified." });
    }

    try {
        const emailBody = warning.body(userName, commentId || 'N/A');

        // 1. Send the email
        await sendEmail(email, warning.subject, emailBody);
        
        // 2. 🛑 NEW LOGIC: Store the Warning Record in the Database 🛑
        const insertSql = `
            INSERT INTO warnings 
            (user_email, user_role, warning_type, comment_id, is_resolved)
            VALUES (?, ?, ?, ?, ?)
        `;
        const insertParams = [
            email, 
            role, 
            warningType, 
            commentId || null, 
            false
        ];
        
        // DB me query chalao (asynchronous call)
        db.query(insertSql, insertParams, (err, result) => {
            if (err) {
                console.error("Warning Log Insert Error:", err);
                // We proceed to success even if log fails, but log the error
            }
        });
        
        // Final success response
        res.json({ 
            message: `Warning (${warningType}) sent successfully to ${userName} and logged.`,
            warningLevel: warning.level
        });
        
    } catch (error) {
        console.error("Warning Email Failed:", error);
        // Agar email hi fail ho jaye, toh 500 status code denge
        res.status(500).json({ error: "Failed to send warning email or log." });
    }
};