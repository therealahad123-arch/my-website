const db = require('../config/db');

// 1. Get Profile
exports.getProfile = (req, res) => {
    // req.user.id ab middleware se sahi milega
    const teacherId = req.user.id; 

    const sql = "SELECT name, email, qualification, experience, photo FROM teachers WHERE id = ?";
    db.query(sql, [teacherId], (err, result) => {
        if (err) return res.status(500).json({ error: err.message });
        if (result.length === 0) return res.status(404).json({ message: "Teacher not found" });
        res.json(result[0]);
    });
};

// 2. Update Profile
exports.updateProfile = (req, res) => {
    const teacherId = req.user.id;
    const { name, qualification, experience } = req.body;

    const sql = "UPDATE teachers SET name = ?, qualification = ?, experience = ? WHERE id = ?";
    
    db.query(sql, [name, qualification, experience, teacherId], (err, result) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ message: "Profile updated successfully" });
    });
};

// 3. My Feedbacks
exports.getMyFeedbacks = (req, res) => {
    const teacherId = req.user.id;
    const sql = "SELECT * FROM feedbacks WHERE teacher_id = ? ORDER BY created_at DESC";
    db.query(sql, [teacherId], (err, results) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(results);
    });
};

// 4. All Feedbacks
exports.getAllFeedbacks = (req, res) => {
    const sql = `
        SELECT feedbacks.*, teachers.name as teacher_name 
        FROM feedbacks 
        JOIN teachers ON feedbacks.teacher_id = teachers.id 
        ORDER BY feedbacks.created_at DESC
    `;
    db.query(sql, (err, results) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(results);
    });
};

// 5. Toggle Like
exports.toggleLike = (req, res) => {
    const { feedbackId } = req.body;
    const sql = "UPDATE feedbacks SET is_liked = NOT is_liked WHERE id = ?";
    db.query(sql, [feedbackId], (err, result) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ message: "Like status updated" });
    });
};

// 6. Post Reply
exports.postReply = (req, res) => {
    const { feedbackId, replyText } = req.body;
    const sql = "UPDATE feedbacks SET reply = ? WHERE id = ?";
    db.query(sql, [replyText, feedbackId], (err, result) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ message: "Reply sent successfully" });
    });
};