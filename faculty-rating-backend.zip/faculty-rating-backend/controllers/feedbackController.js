const db = require('../config/db');

// ==================================================
// 1. SUBMIT FEEDBACK (5 Parameters + Average Logic)
// ==================================================
exports.submitFeedback = (req, res) => {
    // Frontend se ye 5 ratings aur teacher_id aayega
    const { 
        teacher_id, 
        teaching_style, 
        behaviour, 
        explanation, 
        subject_knowledge, 
        punctuality, 
        comment 
    } = req.body;

    // Student ID hum token se nikalenge (Secure tareeka)
    // Note: Ensure kariye ki routes me 'authenticateToken' middleware laga ho
    const student_id = req.user ? req.user.id : null; 

    if (!student_id) {
        return res.status(401).json({ error: "Unauthorized: Student ID missing" });
    }

    // --- AVERAGE CALCULATION ---
    // Sabko integer banaya taaki galti se string concatenation na ho jaye
    const total = parseInt(teaching_style) + 
                  parseInt(behaviour) + 
                  parseInt(explanation) + 
                  parseInt(subject_knowledge) + 
                  parseInt(punctuality);
    
    // Average nikal kar 1 decimal tak fix kiya (e.g., 4.2)
    const average_rating = (total / 5).toFixed(1);

    const sql = `
        INSERT INTO feedbacks 
        (student_id, teacher_id, rating, teaching_style, behaviour, explanation, subject_knowledge, punctuality, comment, created_at) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
    `;

    db.query(sql, [student_id, teacher_id, average_rating, teaching_style, behaviour, explanation, subject_knowledge, punctuality, comment], (err, result) => {
        if (err) {
            console.error("Database Error:", err);
            return res.status(500).json({ error: "Failed to submit feedback" });
        }
        res.json({ message: "Feedback submitted successfully!" });
    });
};

// ==================================================
// 2. GET FEEDBACKS FOR SPECIFIC TEACHER
// ==================================================
exports.getFeedbacksForTeacher = (req, res) => {
    // Frontend URL me ab ID bhejega (e.g., /api/feedback/teacher/5)
    const teacherId = req.params.teacherId; 

    // Yahan hum Students table se JOIN kar rahe hain taaki Student ka naam dikhe
    const sql = `
        SELECT f.*, s.name as student_name 
        FROM feedbacks f 
        JOIN students s ON f.student_id = s.id 
        WHERE f.teacher_id = ? 
        ORDER BY f.created_at DESC
    `;

    db.query(sql, [teacherId], (err, results) => {
        if (err) {
            console.error(err);
            return res.status(500).json({ error: "Failed to fetch feedbacks" });
        }
        res.json(results);
    });
};

// ==================================================
// 3. GET ALL FEEDBACKS (For Admin Dashboard)
// ==================================================
exports.getAllFeedbacks = (req, res) => {
    // Yahan Student aur Teacher dono ka naam JOIN karke layenge
    const sql = `
        SELECT f.*, s.name as student_name, t.name as teacher_name 
        FROM feedbacks f
        JOIN students s ON f.student_id = s.id
        JOIN teachers t ON f.teacher_id = t.id
        ORDER BY f.created_at DESC
    `;

    db.query(sql, (err, results) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(results);
    });
};

// ==================================================
// 4. DELETE FEEDBACK (Admin Only)
// ==================================================
exports.deleteFeedback = (req, res) => {
    const { id } = req.body;
    const sql = "DELETE FROM feedbacks WHERE id = ?";
    
    db.query(sql, [id], (err, result) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ message: "Feedback deleted successfully" });
    });
};

// controllers/feedbackController.js (File ke end mein add karein)

// ==================================================
// 5. GET ALL PUBLIC FEEDBACKS (For Student/Teacher Feed)
// ==================================================
exports.getPublicFeedbacks = (req, res) => {
    // Ye query sabhi feedbacks laati hai student aur teacher ke naam ke saath
    const sql = `
        SELECT 
            f.id, f.rating, f.comment, f.created_at, f.likes, 
            t.name AS teacher_name, 
            s.name AS student_name 
        FROM feedbacks f
        JOIN teachers t ON f.teacher_id = t.id
        JOIN students s ON f.student_id = s.id
        ORDER BY f.created_at DESC
    `;

    db.query(sql, (err, results) => {
        if (err) return res.status(500).json({ error: "Failed to fetch public feedback feed." });
        res.json(results);
    });
};


// ==================================================
// 6. REPLY TO A FEEDBACK/COMMENT (New Logic)
// ==================================================
exports.replyToFeedback = (req, res) => {
    const student_id = req.user.id; // Jo student comment kar raha hai
    const { feedbackId, replyText } = req.body;

    // Optional: Humne LIKE ka column DB mein add kiya hai, lekin LIKE ki logic abhi JS mein pending hai.
    
    const sql = `
        INSERT INTO feedback_replies (feedback_id, student_id, reply_text, created_at)
        VALUES (?, ?, ?, NOW())
    `;

    db.query(sql, [feedbackId, student_id, replyText], (err, result) => {
        if (err) {
            console.error(err);
            return res.status(500).json({ error: "Failed to post comment/reply." });
        }
        res.json({ message: "Comment posted successfully!" });
    });
};

// ==================================================
// 7. GET REPLIES FOR A FEEDBACK ID (Helper Function)
// ==================================================
exports.getFeedbackReplies = (req, res) => {
    const feedbackId = req.params.feedbackId;
    
    // Yahan hum Students table se join kar rahe hain taaki reply karne wale ka naam dikhe
    const sql = `
        SELECT fr.*, s.name as student_name 
        FROM feedback_replies fr
        JOIN students s ON fr.student_id = s.id
        WHERE fr.feedback_id = ?
        ORDER BY fr.created_at ASC
    `;

    db.query(sql, [feedbackId], (err, results) => {
        if (err) return res.status(500).json({ error: "Failed to fetch replies." });
        res.json(results);
    });
};

// controllers/feedbackController.js (File ke end mein add karein)

// ==================================================
// 8. TOGGLE LIKE/INCREMENT LIKE COUNT
// ==================================================
exports.toggleLike = (req, res) => {
    const { feedbackId } = req.body;
    const studentId = req.user.id; 

    if (!feedbackId || !studentId) {
        return res.status(400).json({ error: "Missing required data." });
    }

    const checkSql = "SELECT * FROM feedback_likes WHERE feedback_id = ? AND student_id = ?";
    
    db.query(checkSql, [feedbackId, studentId], (err, results) => {
        if (err) {
            console.error("Like check error:", err);
            return res.status(500).json({ error: "DB check failed." });
        }
        
        // DEBUG 1: Check karein ki kitne likes mile (0 or 1)
        console.log(">>> DEBUG: Results found:", results.length); 

        if (results.length > 0) {
            // DEBUG 2: 
            console.log(">>> DEBUG: Executing UNLIKE path."); 
            
            // Case 1: ALREADY LIKED - UNLIKE karo
            const unlikeSql = "DELETE FROM feedback_likes WHERE feedback_id = ? AND student_id = ?";
            db.query(unlikeSql, [feedbackId, studentId], (err, result) => {
                if (err) {
                     console.error("DEBUG CRASH 1: DELETE Failed:", err);
                     return res.status(500).json({ error: "Unlike failed (DB error)." });
                }
                
                // CHECK: Dekho kitni rows delete hui hain (Crucial line)
                console.log(">>> DEBUG: Rows Deleted:", result.affectedRows); 

                // feedbacks table mein count ghatao
                db.query("UPDATE feedbacks SET likes = likes - 1 WHERE id = ?", [feedbackId], (err) => {
                    if (err) console.error("DEBUG CRASH 2: Count decrease error:", err);
                    return res.json({ message: "Unliked successfully", action: "UNLIKED" }); 
                });
                return; 
            });
            return; 

        } else {
            // DEBUG 3:
            console.log(">>> DEBUG: Executing LIKE path."); 
            
            // Case 2: NOT LIKED - LIKE karo
            const likeSql = "INSERT INTO feedback_likes (feedback_id, student_id) VALUES (?, ?)";

            db.query(likeSql, [feedbackId, studentId], (err, result) => {
                if (err) {
                    console.error("Like insert error:", err);
                    return res.status(500).json({ error: "Like failed (insert error)." });
                }
                
                db.query("UPDATE feedbacks SET likes = likes + 1 WHERE id = ?", [feedbackId], (err) => {
                    if (err) console.error("Count increase error:", err);
                    return res.json({ message: "Liked successfully", action: "LIKED" });
                });
                return;
            });
            return;
        }
    });
};