const db = require("../config/db");

// POST - Submit a comment
exports.postComment = (req, res) => {
  const { feedback_id, student_id, comment } = req.body;

  if (!feedback_id || !student_id || !comment) {
    return res.status(400).json({ error: "All fields are required" });
  }

  const sql = `
    INSERT INTO feedback_comments (feedback_id, student_id, comment, created_at)
    VALUES (?, ?, ?, NOW())
  `;

  db.query(sql, [feedback_id, student_id, comment], (err, result) => {
    if (err) {
      console.error("Error inserting comment:", err);
      return res.status(500).json({ error: "Internal server error" });
    }

    res.status(201).json({ message: "Comment added successfully" });
  });
};


// GET all comments with student & teacher names
exports.getAllComments = (req, res) => {
  const sql = `
    SELECT 
      fc.comment, 
      fc.created_at,
      s.name AS student_name,
      f.teacher_name
    FROM feedback_comments fc
    JOIN students s ON fc.student_id = s.id
    JOIN feedbacks f ON fc.feedback_id = f.id
    ORDER BY fc.created_at DESC
    LIMIT 0, 25
  `;

  db.query(sql, (err, results) => {
    if (err) {
      console.error("Error fetching comments:", err);
      return res.status(500).json({ error: "Internal server error" });
    }

    res.json(results);
  });
};
