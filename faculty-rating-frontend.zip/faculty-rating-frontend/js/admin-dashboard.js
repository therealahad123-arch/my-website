const token = localStorage.getItem("token");
const user = JSON.parse(localStorage.getItem("user"));

// Backend URLs
const BASE_URL = 'http://localhost:5000/api';

// 1. Initial Check & Setup
document.addEventListener("DOMContentLoaded", () => {
    // Security Check: Agar token nahi hai ya role admin nahi hai to login page par bhejo
    if (!token || !user || user.role !== 'admin') {
        window.location.href = "login.html";
        return;
    }

    // NEW: ADMIN NAME DISPLAY
    if (user && user.name) {
        document.getElementById("adminName").innerText = user.name;
    }

    // Load Data
    loadFeedbacks();
    loadTeachers();
});

// === FEEDBACK MANAGEMENT (STUDENT MODERATION) ===

async function loadFeedbacks() {
    try {
        const res = await fetch(`${BASE_URL}/admin/feedbacks`, {
            headers: { "Authorization": token }
        });
        
        if (!res.ok) throw new Error("Failed to fetch feedbacks.");
        
        const feedbacks = await res.json();
        
        const tbody = document.querySelector("#feedbackTable tbody");
        tbody.innerHTML = "";

        feedbacks.forEach(fb => {
            const row = document.createElement("tr");
            
            // Check if student is blocked (is_active=0)
            const isBlocked = fb.is_active === 0;

            if(isBlocked) {
                row.style.backgroundColor = "#ffdddd"; // Light red for blocked rows
            }

            // --- BLOCK/UNBLOCK Button Logic ---
            const blockBtnText = isBlocked ? '✅ Unblock' : '🚫 Block';
            const blockBtnClass = isBlocked ? 'btn-unblock' : 'btn-block';
            
            // IMPORTANT: Passing all necessary data to the buttons
            const actionButtons = `
                <button class="btn-del" onclick="deleteFeedback(${fb.id})">Delete</button>
                
                <button class="btn-warn" 
                    data-role="student" 
                    data-comment-id="${fb.id}"
                    data-email="${fb.student_email}"
                    data-name="${fb.student_name}"
                    onclick="showWarningModal(this)">⚠️ Warn</button>
                
                <button class="${blockBtnClass}" 
                    data-email="${fb.student_email}"
                    data-role="student"
                    data-current-status="${fb.is_active}"
                    onclick="toggleBlockStatus(this)">
                    ${blockBtnText}
                </button>
            `;


            row.innerHTML = `
                <td>${fb.student_name} <br> <small>${fb.student_email}</small></td>
                <td>${fb.teacher_name}</td>
                <td>${fb.rating}/5</td>
                <td>${fb.comment}</td>
                <td class="action-column">${actionButtons}</td>
            `;
            
            tbody.appendChild(row);
        });
    } catch (err) {
        console.error("Error loading feedbacks:", err);
        alert("Error loading feedbacks. Check console for API details.");
    }
}

// Delete Feedback (STUDENT CONTENT REMOVAL)
async function deleteFeedback(id) {
    if(!confirm("Delete this comment?")) return;
    
    // NOTE: This only deletes the feedback, not the student account.
    await fetch(`${BASE_URL}/admin/delete-feedback`, {
        method: "POST",
        headers: { "Content-Type": "application/json", "Authorization": token },
        body: JSON.stringify({ id })
    });
    loadFeedbacks();
}


// === TEACHER MANAGEMENT (TEACHER MODERATION) === 

async function loadTeachers() {
    try {
        // NOTE: Ensure your teacher API also returns the is_active status
        const res = await fetch(`${BASE_URL}/admin/teachers`, {
            headers: { "Authorization": token }
        });
        
        if (!res.ok) throw new Error("Failed to fetch teachers.");
        
        const teachers = await res.json();

        const tbody = document.querySelector("#teacherTable tbody");
        tbody.innerHTML = "";

        teachers.forEach(t => {
            const row = document.createElement("tr");
            
            // Check if teacher is blocked
            const isBlocked = t.is_active === 0;
            if(isBlocked) row.style.backgroundColor = "#ffdddd"; 

            // --- TEACHER MODERATION BUTTONS ---
            const blockBtnText = isBlocked ? '✅ Unblock' : '🚫 Block';
            const blockBtnClass = isBlocked ? 'btn-unblock' : 'btn-block';

            row.innerHTML = `
                <td>${t.id}</td>
                <td>${t.name}</td>
                <td>${t.email}</td>
                <td>
                    <button class="btn-del" onclick="deleteTeacher(${t.id})">Remove</button>
                    
                    <button class="${blockBtnClass}"
                        data-email="${t.email}"
                        data-role="teacher"
                        data-current-status="${t.is_active}"
                        onclick="toggleBlockStatus(this)">
                        ${blockBtnText}
                    </button>
                </td>
            `;
            tbody.appendChild(row);
        });
    } catch (err) {
        console.error("Error loading teachers:", err);
    }
}

// Delete Teacher (TEACHER ACCOUNT REMOVAL)
async function deleteTeacher(id) {
    if(!confirm("Remove this teacher permanently?")) return;
    
    // NOTE: This deletes the teacher account and associated records (depending on backend).
    await fetch(`${BASE_URL}/admin/delete-teacher`, {
        method: "POST",
        headers: { "Content-Type": "application/json", "Authorization": token },
        body: JSON.stringify({ id })
    });
    loadTeachers();
}


// ----------------------------------------------------
// SHARED LOGIC (BLOCK / UNBLOCK & WARN)
// ----------------------------------------------------

async function toggleBlockStatus(buttonElement) {
    const userEmail = buttonElement.getAttribute('data-email');
    const role = buttonElement.getAttribute('data-role'); 
    const currentStatus = parseInt(buttonElement.getAttribute('data-current-status'));
    const newStatus = currentStatus === 1 ? 0 : 1;
    const action = newStatus === 0 ? 'BLOCK' : 'UNBLOCK';

    if (!confirm(`Are you sure you want to ${action} ${userEmail} (${role})?`)) {
        return; 
    }
    
    try {
        const response = await fetch(`${BASE_URL}/auth/toggleUserStatus`, {
            method: 'POST',
            headers: { "Content-Type": "application/json", "Authorization": token },
            body: JSON.stringify({ 
                email: userEmail,
                role: role, 
                status: newStatus 
            })
        });

        const data = await response.json();

        if (response.ok) {
            alert(data.message);
            loadFeedbacks(); 
            loadTeachers(); 
        } else {
            alert(`Error: ${data.error}`);
        }
    } catch (error) {
        console.error("Toggle Status Error:", error);
        alert("Server connection failed or an unexpected error occurred.");
    }
}


async function showWarningModal(buttonElement) {
    
    const studentEmail = buttonElement.getAttribute('data-email');
    const studentName = buttonElement.getAttribute('data-name');
    const role = buttonElement.getAttribute('data-role'); 
    const commentId = buttonElement.getAttribute('data-comment-id');

    const warningType = 'VULGAR_LANGUAGE'; // Hardcoded for simplicity
    const warningText = 'Abusive Content (VULGAR_LANGUAGE)';

    if (!confirm(`Confirm sending [${warningText}] warning to ${studentName} (${studentEmail})?`)) return;
    
    try {
        const response = await fetch(`${BASE_URL}/notifications/sendWarning`, {
            method: "POST",
            headers: { "Content-Type": "application/json", "Authorization": token },
            body: JSON.stringify({ 
                email: studentEmail, 
                userName: studentName, 
                role: role, 
                warningType: warningType, 
                commentId: commentId 
            })
        });

        const data = await response.json();
        
        if (response.ok) {
            alert(`Warning Sent: ${data.message}`);
        } else {
            alert(`Warning Send Error: ${data.error}`);
        }
    } catch (err) {
        console.error("Warning API Error:", err);
        alert("Failed to connect to Warning API.");
    }
}


// Add Teacher (Logic remains the same)
async function addTeacher(e) {
    e.preventDefault();
    
    const name = document.getElementById("t-name").value;
    const email = document.getElementById("t-email").value;
    const password = document.getElementById("t-pass").value;
    const qualification = document.getElementById("t-qual").value;
    const experience = document.getElementById("t-exp").value; 

    const res = await fetch(`${BASE_URL}/admin/add-teacher`, {
        method: "POST",
        headers: { "Content-Type": "application/json", "Authorization": token },
        body: JSON.stringify({ name, email, password, qualification, experience })
    });

    const data = await res.json();
    if(res.ok) {
        alert("Teacher Added Successfully!");
        document.querySelector("form").reset(); 
        loadTeachers(); 
    } else {
        alert(data.error);
    }
}


// Navigation & Logout (Logic remains the same)
function showSection(id, btnElement) {
    document.querySelectorAll('.section').forEach(s => s.classList.remove('active'));
    document.getElementById(id).classList.add('active');
    
    if (btnElement) {
        document.querySelectorAll('.menu-btn').forEach(b => b.classList.remove('active'));
        btnElement.classList.add('active');
    }
}

function logout() {
    if(confirm("Logout Admin?")) {
        localStorage.clear();
        window.location.href = "index.html"; 
    }
}