// 1. Page Load hote hi ye chalega
window.onload = function() {
    // A. Purana kaam: Fields clear karo (Auto-fill rokne ke liye)
    if(document.getElementById("email")) document.getElementById("email").value = "";
    if(document.getElementById("password")) document.getElementById("password").value = "";

    // =======================================================
    // B. NYA CODE YAHAN HAI: URL se Role Select karna ✅
    // =======================================================
    const urlParams = new URLSearchParams(window.location.search);
    const roleParam = urlParams.get('role'); // URL se ?role=... nikalo

    if (roleParam) {
        const roleDropdown = document.getElementById("role");
        if (roleDropdown) {
            // Dropdown ki value wahi set kardo jo URL me aayi hai
            roleDropdown.value = roleParam; 
        }
    }
    // =======================================================
}


// 2. Eye Icon Logic
function togglePassword() {
    const passwordInput = document.getElementById("password");
    const eyeIcon = document.getElementById("toggleEye");

    if (passwordInput.type === "password") {
        passwordInput.type = "text";
        eyeIcon.classList.remove("fa-eye");
        eyeIcon.classList.add("fa-eye-slash");
    } else {
        passwordInput.type = "password";
        eyeIcon.classList.remove("fa-eye-slash");
        eyeIcon.classList.add("fa-eye");
    }
}

// 3. Handle Login
async function handleLogin(event) {
    event.preventDefault(); // Page refresh hone se roko

    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;
    const role = document.getElementById("role").value;

    if (!email || !password) {
        alert("Please fill all fields");
        return;
    }

    // Role ke hisab se sahi API endpoint chuno
    let endpoint = "";
    if (role === 'student') endpoint = "loginStudent";
    else if (role === 'teacher') endpoint = "loginTeacher";
    else if (role === 'admin') endpoint = "loginAdmin";

    const btn = document.getElementById("loginBtn");
    const originalText = btn.innerText;
    btn.innerText = "Logging in...";
    btn.disabled = true;

    try {
        const res = await fetch(`http://localhost:5000/api/auth/${endpoint}`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ email, password })
        });

        const data = await res.json();

        if (res.ok) {
            // Token aur User info save karo
            localStorage.setItem("token", data.token);
            localStorage.setItem("user", JSON.stringify(data.user));
            
            // Redirect Logic
            if (role === 'admin') {
                window.location.href = "admin-dashboard.html";
            } else if (role === 'teacher') {
                window.location.href = "teacher-dashboard.html";
            } else {
                window.location.href = "student-dashboard.html";
            }
        } else {
            alert(data.error); // Error dikhao (Wrong password / Not verified)
            
            // Agar account verify nahi hai, to alert me hint do
            if(data.error && data.error.includes("verify")) {
                 // Aap chaho to yahan unhe wapas register page bhej sakte ho
                 // window.location.href = "register.html";
            }
            
            btn.innerText = originalText;
            btn.disabled = false;
        }

    } catch (err) {
        console.error(err);
        alert("Server Connection Failed");
        btn.innerText = originalText;
        btn.disabled = false;
    }
}