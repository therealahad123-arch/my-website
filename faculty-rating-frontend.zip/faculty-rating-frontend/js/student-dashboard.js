// Global Variables for 5-Star Rating System
let currentRatings = {
    teaching_style: 0,
    behaviour: 0,
    explanation: 0,
    subject_knowledge: 0,
    punctuality: 0
};

// Backend URLs
const BASE_URL = 'http://localhost:5000/api';
let user;
let token;

// =================================================
// 1. PAGE LOAD & INITIAL SETUP
// =================================================

function init() {
    token = localStorage.getItem("token");
    const userStr = localStorage.getItem("user");

    if (!token || !userStr) {
        window.location.href = "login.html";
        return;
    }

    user = JSON.parse(userStr);
    
    // Header Name Update
    if(document.getElementById("studentName")) {
        document.getElementById("studentName").innerText = user.name;
    }

    // Load Teachers (Rate Faculty tab ka default data)
    loadTeachers();
    
    // Check for Warnings on every login/page load
    checkForUnviewedWarnings();
}

window.onload = init;


// =================================================
// 2. DATA LOADING FUNCTIONS
// =================================================

// Teachers Grid Load Karna
async function loadTeachers() {
    try {
        const res = await fetch(`${BASE_URL}/student/teachers`, {
            headers: { "Authorization": token }
        });
        
        const teachers = await res.json();
        const grid = document.getElementById("teachersGrid");
        
        if (!res.ok || teachers.error) {
            grid.innerHTML = `<p class="col-span-3 text-red-500 text-center">❌ Failed to load teachers.</p>`;
            return;
        }

        if (teachers.length === 0) {
            grid.innerHTML = `<p class="col-span-3 text-gray-500 text-center">No teachers found in the database.</p>`;
            return;
        }

        grid.innerHTML = "";

        teachers.forEach(teacher => {
            const card = `
                <div class="bg-white p-6 rounded-xl shadow hover:shadow-xl transition border border-gray-100 flex flex-col items-center text-center">
                    <div class="w-16 h-16 bg-blue-50 text-blue-600 rounded-full flex items-center justify-center text-2xl font-bold mb-4">
                        ${teacher.name.charAt(0)}
                    </div>
                    <h3 class="text-xl font-bold text-gray-800">${teacher.name}</h3>
                    <p class="text-gray-500 text-sm mb-1">${teacher.qualification || 'Faculty'}</p>
                    <p class="text-blue-500 text-xs font-semibold uppercase tracking-wide mb-6">${teacher.department || 'Department'}</p>
                    
                    <button onclick="openFeedbackModal(${teacher.id})" 
                        class="w-full bg-blue-600 text-white py-2 rounded-lg font-semibold hover:bg-blue-700 transition">
                        Rate Faculty
                    </button>
                </div>
            `;
            grid.innerHTML += card;
        });

    } catch (err) {
        console.error("Fetch Error:", err);
        document.getElementById("teachersGrid").innerHTML = `<p class="col-span-3 text-red-500 text-center">Connection Error. Check your Node.js Server.</p>`;
    }
}

// =================================================
// 3. RATING CORE LOGIC (Star Functions)
// =================================================

function openFeedbackModal(teacherId) {
    document.getElementById("modalTeacherId").value = teacherId;
    document.getElementById("feedbackModal").classList.remove("hidden");
    
    currentRatings = { teaching_style: 0, behaviour: 0, explanation: 0, subject_knowledge: 0, punctuality: 0 };
    document.getElementById("feedbackComment").value = "";
    resetStars(); 
}

function closeModal() {
    document.getElementById("feedbackModal").classList.add("hidden");
}

function setRate(category, value) {
    currentRatings[category] = value;
    updateStarVisuals(category, value);
}

function updateStarVisuals(category, value) {
    const container = document.getElementById(`star-${category}`);
    if(!container) return;

    const stars = container.getElementsByTagName("i");
    
    for (let i = 0; i < 5; i++) {
        if (i < value) {
            stars[i].classList.add("text-yellow-400");
            stars[i].classList.remove("text-gray-300");
        } else {
            stars[i].classList.add("text-gray-300");
            stars[i].classList.remove("text-yellow-400");
        }
    }
}

function resetStars() {
    ['teaching_style', 'behaviour', 'explanation', 'subject_knowledge', 'punctuality'].forEach(cat => {
        updateStarVisuals(cat, 0);
    });
}

// 4. SUBMIT FEEDBACK
async function submitFeedback() {
    const teacherId = document.getElementById("modalTeacherId").value;
    const comment = document.getElementById("feedbackComment").value;
    
    if (Object.values(currentRatings).some(r => r === 0)) {
        alert("⚠️ Please rate all 5 categories before submitting!");
        return;
    }

    const submitBtn = document.querySelector("#feedbackModal button:last-child");
    const oldText = submitBtn.innerText;
    submitBtn.innerText = "Submitting...";
    submitBtn.disabled = true;

    try {
        const res = await fetch(`${BASE_URL}/feedback/add`, {
            method: "POST",
            headers: { 
                "Content-Type": "application/json",
                "Authorization": token
            },
            body: JSON.stringify({ 
                teacher_id: teacherId, 
                ...currentRatings, 
                comment: comment 
            })
        });

        const data = await res.json();
        
        if (res.ok) {
            alert("✅ Feedback Submitted Successfully!");
            closeModal();
        } else {
            alert("❌ Error: " + (data.error || "Submission failed"));
        }
    } catch (err) {
        console.error(err);
        alert("❌ Server Error: Check backend connection.");
    } finally {
        submitBtn.innerText = oldText;
        submitBtn.disabled = false;
    }
}

// =================================================
// 5. UI TAB SWITCHING LOGIC
// =================================================

function showSection(id, element) {
    document.querySelectorAll('.section').forEach(s => s.classList.add('hidden'));
    document.getElementById(id).classList.remove('hidden');
    
    document.querySelectorAll('.tab-btn').forEach(b => {
        b.classList.remove('active', 'text-blue-600', 'border-blue-600');
        b.classList.add('text-gray-500', 'border-transparent');
    });

    if (element) {
        element.classList.add('active', 'text-blue-600', 'border-blue-600');
        element.classList.remove('text-gray-500', 'border-transparent');
    }

    // Data Load Trigger
    if (id === 'view-feedbacks') {
        loadPublicFeedbacks();
    }
}

// =================================================
// 6. PUBLIC FEEDBACKS & COMMENT LOGIC
// =================================================

async function loadPublicFeedbacks() {
    const listContainer = document.getElementById("publicFeedbacksList");
    listContainer.innerHTML = `<p class="text-center text-gray-500">Fetching community data...</p>`;
    
    try {
        const res = await fetch(`${BASE_URL}/feedback/public-feed`, {
            headers: { "Authorization": token }
        });

        const feedbacks = await res.json();
        listContainer.innerHTML = "";

        if (!res.ok || feedbacks.length === 0) {
            listContainer.innerHTML = `<p class="text-center text-gray-500">No feedbacks found or error loading feed.</p>`;
            return;
        }

        feedbacks.forEach(fb => {
            const card = document.createElement('div');
            card.className = "bg-white p-5 rounded-xl shadow-md border border-gray-100";
            card.innerHTML = `
                <div class="flex justify-between items-center mb-3">
                    <span class="text-sm font-semibold text-blue-700">TO: ${fb.teacher_name}</span>
                    <span class="text-xs text-gray-500">${new Date(fb.created_at).toLocaleDateString()}</span>
                </div>
                <p class="text-base italic mb-3">"${fb.comment}"</p>
                
                <div class="flex justify-between items-center text-sm border-t pt-3 mt-3">
                    <span class="font-medium text-gray-700">BY: ${fb.student_name}</span>
                    <span class="text-yellow-500 font-bold"><i class="fa-solid fa-star"></i> ${fb.rating} / 5</span>
                </div>
                
                <div class="mt-4 pt-3 border-t">
                    <div class="flex gap-4 mb-2">
                        <button onclick="toggleLike(${fb.id}, this)" class="text-blue-500 hover:text-blue-700 font-semibold text-sm">
                            <i class="fa-solid fa-thumbs-up"></i> Like (${fb.likes || 0})
                        </button>
                        <button onclick="toggleReplyInput(${fb.id})" class="text-gray-500 hover:text-gray-700 font-semibold text-sm">
                            <i class="fa-solid fa-reply"></i> Comment
                        </button>
                    </div>
                    
                    <div id="reply-area-${fb.id}" class="hidden mt-3">
                        <textarea id="reply-text-${fb.id}" class="w-full p-2 border rounded-lg resize-none text-sm" rows="1" placeholder="Write your comment..."></textarea>
                        <button onclick="postReply(${fb.id})" class="mt-2 bg-blue-500 text-white px-4 py-1 rounded-lg text-xs hover:bg-blue-600">Post</button>
                    </div>
                </div>
                <div id="replies-list-${fb.id}" class="text-xs mt-3 p-2 bg-gray-50 rounded"></div>
            `;
            listContainer.appendChild(card);
            
            loadReplies(fb.id); 
        });

    } catch (err) {
        listContainer.innerHTML = `<p class="text-center text-red-500">Error loading feed: ${err.message}</p>`;
        console.error(err);
    }
}

function toggleReplyInput(feedbackId) {
    const area = document.getElementById(`reply-area-${feedbackId}`);
    area.classList.toggle('hidden');
}

async function postReply(feedbackId) {
    const replyText = document.getElementById(`reply-text-${feedbackId}`).value;
    
    if (!replyText.trim()) return;

    try {
        const res = await fetch(`${BASE_URL}/feedback/reply-to-feedback`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'Authorization': token },
            body: JSON.stringify({ feedbackId, replyText })
        });

        if (res.ok) {
            document.getElementById(`reply-text-${feedbackId}`).value = ''; 
            toggleReplyInput(feedbackId); 
            loadReplies(feedbackId); 
        } else {
            alert("Failed to post reply.");
        }
    } catch (err) {
        console.error(err);
        alert("Server communication failed.");
    }
}

async function loadReplies(feedbackId) {
    const list = document.getElementById(`replies-list-${feedbackId}`);
    list.innerHTML = `<p class="text-gray-400 italic text-center">Loading comments...</p>`;
    
    try {
        const res = await fetch(`${BASE_URL}/feedback/replies/${feedbackId}`, {
            headers: { 'Authorization': token }
        });
        const replies = await res.json();
        
        list.innerHTML = '';
        if (replies.length > 0) {
            list.innerHTML = `<p class="font-bold text-gray-700 mb-1">Comments (${replies.length}):</p>`;
            replies.forEach(r => {
                list.innerHTML += `<div class="p-1 pl-4 border-l-2 border-blue-200 text-gray-700"><strong>${r.student_name}:</strong> ${r.reply_text}</div>`;
            });
        } else {
            list.innerHTML = `<p class="text-gray-500 italic text-center">No comments yet.</p>`;
        }
    } catch (err) {
        list.innerHTML = `<p class="text-red-500">Could not load comments.</p>`;
        console.error(err);
    }
}

async function toggleLike(feedbackId, element) {
    element.disabled = true;

    try {
        const res = await fetch(`${BASE_URL}/feedback/like-feedback`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'Authorization': token },
            body: JSON.stringify({ feedbackId })
        });

        const data = await res.json(); 
        
        if (res.ok) {
            const currentText = element.innerText;
            const currentCount = parseInt(currentText.match(/(\d+)/)[0]);
            let newCount;
            
            // Check karo ki server ne kya action liya (LIKED ya UNLIKED)
            if (data.action === "LIKED") {
                newCount = currentCount + 1;
                element.classList.add('text-blue-700', 'font-bold'); // Highlight for Liked
            } else if (data.action === "UNLIKED") {
                newCount = currentCount - 1;
                element.classList.remove('text-blue-700', 'font-bold'); // Remove Highlight
            } else {
                newCount = currentCount; 
            }

            // UI Update: Count update karo
            element.innerHTML = `<i class="fa-solid fa-thumbs-up"></i> Like (${newCount})`;
            
        } else {
            alert("Error: Action failed. Please try again.");
        }
    } catch (err) {
        alert("Could not connect to server for like.");
        console.error(err);
    } finally {
        element.disabled = false;
    }
}


// =================================================
// 7. 🛑 WARNING NOTIFICATION LOGIC (NEWLY ADDED) 🛑
// =================================================

// This function is called immediately on page load via init()
async function checkForUnviewedWarnings() {
    try {
        const response = await fetch(`${BASE_URL}/student/warnings`, {
            headers: { "Authorization": token }
        });

        if (!response.ok) {
            console.error("Failed to fetch warnings (API Error).");
            return;
        }

        const data = await response.json();
        const unviewedWarnings = data.warnings;

        if (unviewedWarnings && unviewedWarnings.length > 0) {
            
            const latestWarning = unviewedWarnings[0]; 
            
            // HTML/Modal Logic: वार्निंग मैसेज तैयार करें
            // Note: यह मैसेज उस कठोर वार्निंग पर आधारित है जो Admin भेजता है
            const warningMessageHTML = `
                <h3 class="text-2xl font-bold text-red-500 mb-3"><i class="fa-solid fa-triangle-exclamation"></i> Official Warning Notice</h3>
                <p class="text-gray-700 mb-3">Dear ${user.name}, you have received an unviewed warning from the University Administration.</p>
                
                <p class="bg-red-50 border-l-4 border-red-400 p-4 text-sm text-gray-800 font-semibold">
                    Violation Type: ${latestWarning.warning_type.replace(/_/g, ' ')} 
                    <span class="text-xs block text-gray-500 mt-1">Issued Date: ${new Date(latestWarning.warning_date).toLocaleDateString()}</span>
                </p>

                <p class="text-red-700 font-bold mt-4">
                    🛑 STRICT ACTION: This is a direct violation of Community Guidelines. Future offenses will result in **permanent account blockage**.
                </p>
            `;

            // HTML Modal को दिखाना
            const modalContent = document.getElementById('warningMessageContent');
            const modal = document.getElementById('warningModal');

            if (modalContent && modal) {
                modalContent.innerHTML = warningMessageHTML;
                modal.classList.remove('hidden'); // Modal ko dikhao
            }
            
            // 3. वार्निंग दिखने के बाद, इसे 'viewed' मार्क करें
            const warningIds = unviewedWarnings.map(w => w.warning_id);
            await markWarningsAsViewed(warningIds);
        }

    } catch (error) {
        console.error("Error during warning check:", error);
        // User ko alert na karein agar sirf check fail hua hai
    }
}

// 8. वार्निंग्स को 'देखी गई' मार्क करने का फ़ंक्शन
async function markWarningsAsViewed(ids) {
    try {
        await fetch(`${BASE_URL}/student/warnings/viewed`, {
            method: 'POST',
            headers: { 
                "Content-Type": "application/json", 
                "Authorization": token 
            },
            body: JSON.stringify({ warningIds: ids })
        });
        console.log("Warnings successfully marked as viewed.");
    } catch (error) {
        console.error("Failed to mark warnings as viewed:", error);
    }
}
function showSection(id, element) {
    // 1. Hide all sections
    document.querySelectorAll('.section').forEach(s => s.classList.add('hidden'));
    // 2. Show selected section
    document.getElementById(id).classList.remove('hidden');
    
    // 3. Update Tab Buttons (Highlight current tab)
    document.querySelectorAll('.tab-btn').forEach(b => {
        // Remove active state
        b.classList.remove('active', 'text-blue-600', 'border-blue-600');
        // Add default inactive state
        b.classList.add('text-gray-500', 'border-transparent');
    });

    if (element) {
        // Add active state to the clicked button
        element.classList.add('active', 'text-blue-600', 'border-blue-600');
        element.classList.remove('text-gray-500', 'border-transparent');
    }

    // Data Load Trigger
    if (id === 'view-feedbacks') {
        loadPublicFeedbacks();
    }
}

// 9. LOGOUT
function logout() {
    if(confirm("Logout Student?")) {
        localStorage.clear();
        window.location.href = "index.html";
    }
}
