// 1. Page Load hote hi ye chalega
window.onload = function() {
    // A. Fields Clear karo (Auto-fill rokne ke liye)
    if(document.getElementById("name")) document.getElementById("name").value = "";
    if(document.getElementById("email")) document.getElementById("email").value = "";
    if(document.getElementById("password")) document.getElementById("password").value = "";
    if(document.getElementById("qualification")) document.getElementById("qualification").value = "";
    if(document.getElementById("otp")) document.getElementById("otp").value = "";

    // =======================================================
    // B. URL se Role Select karna ✅
    // =======================================================
    const urlParams = new URLSearchParams(window.location.search);
    const roleParam = urlParams.get('role'); // URL se ?role=... nikalo

    if (roleParam) {
        const roleDropdown = document.getElementById("role");
        if (roleDropdown) {
            // Dropdown set karo
            roleDropdown.value = roleParam; 
            
            // Important: Agar Teacher hai to Qualification field dikhao
            toggleFields();
        }
    }
    // =======================================================
}

// 2. Eye Icon Logic (Password Show/Hide)
function togglePassword() {
    const passwordInput = document.getElementById("password");
    const eyeIcon = document.getElementById("toggleEye");

    if (passwordInput.type === "password") {
        passwordInput.type = "text";
        eyeIcon.classList.remove("fa-eye");
        eyeIcon.classList.add("fa-eye-slash"); // Kata hua aankh
    } else {
        passwordInput.type = "password";
        eyeIcon.classList.remove("fa-eye-slash");
        eyeIcon.classList.add("fa-eye"); // Normal aankh
    }
}

// Global Variables
let userEmail = "";
let userRole = "";

// 3. Show/Hide Qualification Field based on Role
function toggleFields() {
    const role = document.getElementById("role").value;
    const qualDiv = document.getElementById("qualDiv");
    
    if (role === 'teacher') {
        qualDiv.classList.remove("hidden");
    } else {
        qualDiv.classList.add("hidden");
    }
}

// 4. Handle Registration (Send OTP)
async function handleRegister() {
    const name = document.getElementById("name").value;
    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;
    const role = document.getElementById("role").value;
    const qualification = document.getElementById("qualification").value;

    // Validation
    if (!name || !email || !password) {
        alert("Please fill all fields");
        return;
    }
    
    // API Endpoint Selection
    let endpoint = "";
    if (role === 'student') endpoint = "registerStudent";
    else if (role === 'teacher') endpoint = "registerTeacher";
    else if (role === 'admin') endpoint = "registerAdmin";

    // Button Loading State
    const btn = document.getElementById("regBtn");
    const originalText = btn.innerText;
    btn.innerText = "Sending OTP...";
    btn.disabled = true;

    try {
        const res = await fetch(`http://localhost:5000/api/auth/${endpoint}`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ name, email, password, qualification })
        });

        const data = await res.json();

        if (res.ok) {
            alert("OTP Sent Successfully! Check your Email.");
            
            // Data save karo agle step ke liye
            userEmail = email;
            userRole = role;

            // UI Switch karo
            document.getElementById("step1").classList.add("hidden");
            document.getElementById("step2").classList.remove("hidden");
            document.getElementById("headerTitle").innerText = "Verify OTP";
        } else {
            alert("Error: " + data.error);
            btn.innerText = originalText;
            btn.disabled = false;
        }
    } catch (err) {
        console.error(err);
        alert("Server Connection Failed. Is backend running?");
        btn.innerText = originalText;
        btn.disabled = false;
    }
}

// 5. Handle Verify OTP
async function handleVerify() {
    const otp = document.getElementById("otp").value;

    if (!otp) {
        alert("Please enter the OTP");
        return;
    }

    const btn = document.getElementById("verifyBtn");
    const originalText = btn.innerText;
    btn.innerText = "Verifying...";
    btn.disabled = true;

    try {
        const res = await fetch('http://localhost:5000/api/auth/verify-otp', {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ email: userEmail, otp: otp, role: userRole })
        });

        const data = await res.json();

        if (res.ok) {
            alert("Verification Successful! Redirecting to Login...");
            window.location.href = "login.html";
        } else {
            alert("Failed: " + data.error);
            btn.innerText = originalText;
            btn.disabled = false;
        }
    } catch (err) {
        console.error(err);
        alert("Verification Error");
        btn.innerText = originalText;
        btn.disabled = false;
    }
}