document.addEventListener("DOMContentLoaded", function() {
    
    // 1. LocalStorage se 'user' wala data nikalo
    const storedUser = localStorage.getItem("user");

    if (storedUser) {
        // 2. Data string format me hota hai, usse wapas Object banao
        const userData = JSON.parse(storedUser);

        // 3. User ka naam check karo (Backend se 'name' ya 'fullName' jo bhi aa raha ho)
        // Agar naam nahi mila to default 'Teacher' dikhayega
        const userName = userData.name || userData.fullName || "Teacher";

        // 4. HTML me wo naam set kar do
        document.getElementById("logged-in-name").innerText = userName;
    } else {
        // Agar user login hi nahi hai, to wapas login page bhej do (Optional security)
        // window.location.href = "login.html";
        console.log("No user logged in");
    }
});

// Function to switch tabs
function showSection(sectionId, btnElement) {
    // 1. Saare sections ko chhupa do
    const sections = document.querySelectorAll('.section');
    sections.forEach(sec => {
        sec.classList.remove('active');
    });

    // 2. Sirf select kiya hua section dikhao
    document.getElementById(sectionId).classList.add('active');

    // 3. Buttons ki styling update karo
    const buttons = document.querySelectorAll('.menu-btn');
    buttons.forEach(btn => {
        btn.classList.remove('active');
    });
    
    // Jis button pe click hua usko active karo
    btnElement.classList.add('active');
}

// Function for Logout
function logout() {
    let confirmLogout = confirm("Are you sure you want to logout?");
    if (confirmLogout) {
        // Yahan 'login.html' ya 'index.html' ka naam dalein jahan redirect karna hai
        window.location.href = "index.html"; 
    }
}

// Function for Like Button (Demo)
function likeFeedback(btn) {
    if (btn.innerHTML.includes("Liked")) {
        btn.innerHTML = "❤️ Like";
        btn.style.backgroundColor = "#e67e22";
    } else {
        btn.innerHTML = "❤️ Liked";
        btn.style.backgroundColor = "#c0392b";
    }
}

// Function for Reply Button (Demo)
function replyFeedback() {
    let reply = prompt("Enter your reply to the student:");
    if (reply) {
        alert("Your reply has been sent! (Demo)");
    }
}

// Function to handle Profile Save
function saveProfile(event) {
    event.preventDefault(); // Page reload hone se rokta hai
    
    // Form se data uthana (Demo purpose)
    const name = document.getElementById('t-name').value;
    const qual = document.getElementById('t-qual').value;
    
    if(name === "" || qual === "") {
        alert("Please fill in the details.");
        return;
    }

    // Success message
    alert("Profile Updated Successfully!\nName: " + name);
}
// Token jo login ke waqt save kiya tha
const token = localStorage.getItem("token");

// 1. Profile Data Load karna
async function loadProfile() {
    const res = await fetch('http://localhost:5000/api/teacher/profile', {
        headers: { "Authorization": token } // Token bhejna zaroori hai
    });
    const data = await res.json();
    
    if(res.ok) {
        // Backend se data lekar input box me bharna
        document.getElementById('t-name').value = data.name;
        document.getElementById('t-qual').value = data.qualification;
        document.getElementById('t-exp').value = data.experience;
    }
}

// 2. Profile Save karna
async function saveProfile(event) {
    event.preventDefault();
    
    const name = document.getElementById('t-name').value;
    const qual = document.getElementById('t-qual').value;
    const exp = document.getElementById('t-exp').value;

    const res = await fetch('http://localhost:5000/api/teacher/profile', {
        method: "PUT",
        headers: { 
            "Content-Type": "application/json",
            "Authorization": token 
        },
        body: JSON.stringify({ name, qualification: qual, experience: exp })
    });

    if(res.ok) {
        alert("Profile Updated!");
    }
}

// Page load hone par profile fetch karo
document.addEventListener("DOMContentLoaded", loadProfile);

async function loadMyFeedbacks() {
    const token = localStorage.getItem("token");
    
    const res = await fetch('http://localhost:5000/api/teacher/my-feedbacks', {
        headers: { "Authorization": token }
    });
    const feedbacks = await res.json();

    const container = document.getElementById("my-feedback");
    
    // Purana content clear karo
    container.innerHTML = `<h3>My Student Ratings</h3><p class="section-desc">Students who rated YOU specifically.</p>`;

    feedbacks.forEach(fb => {
        const likeColor = fb.is_liked ? "#c0392b" : "#e67e22"; 
        const likeText = fb.is_liked ? "❤️ Liked" : "❤️ Like";

        // ---> MAGIC PART: Agar Reply hai to use HTML me dikhao <---
        let replyHTML = "";
        if (fb.reply && fb.reply !== "") {
            replyHTML = `
                <div style="background-color: #e8f8f5; padding: 10px; margin-top: 10px; border-left: 4px solid #2ecc71; border-radius: 4px;">
                    <strong>Your Reply:</strong> ${fb.reply}
                </div>
            `;
        }

        const card = `
            <div class="feedback-card">
                <h4>Student: ${fb.student_name} <span class="stars">★ ${fb.rating}/5</span></h4>
                <p>"${fb.comment}"</p>
                
                ${replyHTML}
                
                <div class="actions">
                    <button class="btn" style="background-color: ${likeColor}; color: white;" 
                        onclick="toggleLikeBtn(this, ${fb.id})">
                        ${likeText}
                    </button>

                    <button class="btn btn-reply" onclick="sendReply(${fb.id})">
                        ${fb.reply ? "✏️ Edit Reply" : "💬 Reply"}
                    </button>
                </div>
            </div>
        `;
        container.innerHTML += card;
    });
}