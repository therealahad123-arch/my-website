const API_BASE = "http://localhost:5000/api";

// Load all feedbacks on page load
window.onload = async () => {
  try {
    const res = await fetch(`${API_BASE}/student/all`);
    const data = await res.json();
    const feedbacks = data.feedbacks || [];

    renderFeedbacks(feedbacks);
  } catch (err) {
    console.error("Error fetching feedbacks:", err);
  }
};

// Render feedbacks in the DOM
function renderFeedbacks(feedbacks) {
  const container = document.getElementById("feedback-list");
  container.innerHTML = "";

  feedbacks.forEach(fb => {
    const item = document.createElement("div");
    item.classList.add("feedback-item");

    item.innerHTML = `
      <h4>From: ${fb.student_name}</h4>
      <h5>To: ${fb.teacher_name}</h5>
      <p>${fb.comment}</p>

      <div class="feedback-actions">
        <button onclick="likeFeedback(${fb.id}, '${fb.student_name}', '${fb.teacher_name}')">👍 Like</button>
        <button onclick="dislikeFeedback(${fb.id}, '${fb.student_name}', '${fb.teacher_name}')">👎 Dislike</button>
        <button onclick="replyToFeedback(${fb.id})">💬 Reply</button>
      </div>

      <div id="reply-box-${fb.id}" class="reply-box" style="display: none;">
        <textarea id="reply-input-${fb.id}" placeholder="Type your reply here..."></textarea>
        <button onclick="submitReply(${fb.id})">Send Reply</button>
      </div>
    `;

    container.appendChild(item);
  });
}

// Like feedback
async function likeFeedback(id, student, teacher) {
  try {
    const res = await fetch(`${API_BASE}/teacher/like`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ feedbackId: id }),
    });
    const data = await res.json();
    alert(`Liked ${student}'s feedback on ${teacher}`);
  } catch (err) {
    alert("Error liking feedback");
  }
}

// Dislike feedback
async function dislikeFeedback(id, student, teacher) {
  try {
    const res = await fetch(`${API_BASE}/teacher/dislike`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ feedbackId: id }),
    });
    const data = await res.json();
    alert(`Disliked ${student}'s feedback on ${teacher}`);
  } catch (err) {
    alert("Error disliking feedback");
  }
}

// Show reply input box
function replyToFeedback(id) {
  const box = document.getElementById(`reply-box-${id}`);
  box.style.display = box.style.display === "none" ? "block" : "none";
}

// Submit reply to backend
async function submitReply(id) {
  const replyText = document.getElementById(`reply-input-${id}`).value;

  if (!replyText) {
    alert("Please write a reply");
    return;
  }

  try {
    const res = await fetch(`${API_BASE}/teacher/reply`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ feedback_id: id, reply: replyText }),
    });

    const data = await res.json();
    alert("Reply submitted!");
    document.getElementById(`reply-box-${id}`).style.display = "none";
  } catch (err) {
    alert("Failed to submit reply.");
  }
}
