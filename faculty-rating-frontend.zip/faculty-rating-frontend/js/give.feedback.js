const API_BASE = "http://localhost:5000/api";

// Load student from localStorage
const user = JSON.parse(localStorage.getItem("user"));
if (!user || user.role !== "student") {
  alert("Unauthorized access");
  window.location.href = "login.html";
}

// Load teacher list
window.onload = () => {
  fetch(`${API_BASE}/admin/teachers`)
    .then(res => res.json())
    .then(data => {
      const dropdown = document.getElementById("teacherName");
      data.teachers.forEach(teacher => {
        const option = document.createElement("option");
        option.value = teacher.name;
        option.textContent = `${teacher.name} (${teacher.department})`;
        dropdown.appendChild(option);
      });
    })
    .catch(err => {
      console.error("Error loading teachers", err);
      alert("Failed to load teacher list");
    });
};

// Submit feedback
document.getElementById("feedbackForm").addEventListener("submit", function (e) {
  e.preventDefault();

  const payload = {
    student_name: user.name,
    teacher_name: document.getElementById("teacherName").value,
    teachingStyle: parseInt(document.getElementById("teachingStyle").value),
    explanation: parseInt(document.getElementById("explanation").value),
    behaviour: parseInt(document.getElementById("behaviour").value),
    comment: document.getElementById("comment").value.trim(),
  };

  fetch(`${API_BASE}/student/submit`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload)
  })
    .then(res => res.json())
    .then(data => {
      alert("Feedback submitted successfully!");
      this.reset();
    })
    .catch(err => {
      console.error("Submission error", err);
      alert("Failed to submit feedback");
    });
});

// Logout
function logout() {
  localStorage.clear();
  window.location.href = "login.html";
}
