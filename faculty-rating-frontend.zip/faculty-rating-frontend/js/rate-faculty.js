document.addEventListener('DOMContentLoaded', () => {
  fetchTeachers();

  const student = JSON.parse(localStorage.getItem('student'));
  if (student?.name) {
    document.getElementById('studentName').innerText = student.name;
    document.getElementById('username').value = student.name;
  }

  document.getElementById('feedbackForm').addEventListener('submit', async (e) => {
    e.preventDefault();

    const payload = {
      studentName: document.getElementById('username').value,
      teacherId: document.getElementById('teacherSelect').value,
      style: document.getElementById('style').value,
      communication: document.getElementById('communication').value,
      clarity: document.getElementById('clarity').value,
      behavior: document.getElementById('behavior').value,
      comment: document.getElementById('comment').value
    };

    const res = await fetch('http://localhost:3000/api/feedback/submit', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });

    const msg = await res.text();
    alert(msg);
    showComment(payload);
    document.getElementById('feedbackForm').reset();
  });
});

function fetchTeachers() {
  fetch('http://localhost:3000/api/teachers/all')
    .then(res => res.json())
    .then(data => {
      const select = document.getElementById('teacherSelect');
      select.innerHTML = data.map(t => `<option value="${t.id}">${t.name}</option>`).join('');
    });
}

function showComment(data) {
  const commentBox = document.createElement('div');
  commentBox.className = "comment-box";
  commentBox.innerHTML = `
    <p><strong>${data.studentName}</strong> rated <strong>${document.getElementById('teacherSelect').selectedOptions[0].text}</strong></p>
    <p>⭐ ${((+data.style + +data.communication + +data.clarity + +data.behavior)/4).toFixed(1)} / 5</p>
    <p>${data.comment}</p>
    <div class="reactions">
      <button onclick="react(this)">👍 <span>0</span></button>
      <button onclick="react(this)">👎 <span>0</span></button>
    </div>
    <div class="reply-box">
      <input placeholder="Reply..." />
      <button onclick="submitReply(this, '${data.studentName}')">Reply</button>
    </div>
    <div class="replies"></div>
  `;
  document.getElementById('commentsSection').prepend(commentBox);
}

function react(btn) {
  const span = btn.querySelector('span');
  span.textContent = parseInt(span.textContent) + 1;
  btn.disabled = true;
}

function submitReply(btn, replierName) {
  const input = btn.previousElementSibling;
  const reply = input.value.trim();
  if (!reply) return;

  const replies = btn.parentElement.nextElementSibling;
  const div = document.createElement('div');
  div.className = 'single-reply';
  div.innerHTML = `<strong>${replierName}:</strong> ${reply}`;
  replies.appendChild(div);
  input.value = '';
}

function logout() {
  if (confirm("Are you sure you want to logout?")) {
    localStorage.removeItem('student');
    window.location.href = 'index.html';  // ✅ Redirect to home page
  }
}

fetch("http://localhost:3000/api/teachers/all")
  .then(res => res.json())
  .then(data => {
    const select = document.getElementById("teacherSelect");
    select.innerHTML = '<option value="" disabled selected>-- Select Teacher --</option>';
    data.forEach(t => {
      const opt = document.createElement('option');
      opt.value = t.id;
      opt.textContent = t.name;
      select.appendChild(opt);
    });
  });

