document.getElementById('forgotForm').addEventListener('submit', function (e) {
  e.preventDefault();

  const userType = document.getElementById('userType').value;
  const emailOrUsername = document.getElementById('emailOrUsername').value;
  const newPassword = document.getElementById('newPassword').value;

  axios.post('http://localhost:3000/api/auth/forgotPassword', {
    userType,
    emailOrUsername,
    newPassword
  })
  .then(res => {
    document.getElementById('forgotMsg').innerText = res.data;
    document.getElementById('forgotMsg').style.color = 'green';
  })
  .catch(err => {
    document.getElementById('forgotMsg').innerText =
      err.response?.data || 'Something went wrong';
    document.getElementById('forgotMsg').style.color = 'red';
  });
});

function sendOtp() {
  const email = document.getElementById('email').value;
  axios.post('/api/otp/send-otp', { email })
    .then(res => {
      document.getElementById('otpMsg').innerText = res.data;
    })
    .catch(err => {
      document.getElementById('otpMsg').innerText = err.response?.data || 'Error';
    });
}

function verifyOtp() {
  const email = document.getElementById('email').value;
  const otp = document.getElementById('otp').value;

  axios.post('/api/otp/verify-otp', { email, otp })
    .then(res => {
      document.getElementById('otpMsg').innerText = res.data;
      // ✅ Proceed to password reset form
      window.location.href = 'reset-password.html?email=' + email;
    })
    .catch(err => {
      document.getElementById('otpMsg').innerText = err.response?.data || 'Error';
    });
}
